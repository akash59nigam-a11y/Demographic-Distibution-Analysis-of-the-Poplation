// App.jsx
// Root component — simply renders the main chart page.
// Add routing here (e.g. React Router) if the project grows.

import PopulationChart from './components/PopulationChart'

export default function App() {
  return <PopulationChart />
}
