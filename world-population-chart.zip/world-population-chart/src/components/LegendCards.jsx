// src/components/LegendCards.jsx
// Grid of summary cards displayed below the bar chart.
// Each card shows region/income name, population, and its % share of the total.

export default function LegendCards({ data, total }) {
  return (
    <div style={{
      display: "grid",
      // Responsive: fills columns naturally; each card minimum 160px wide
      gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))",
      gap: "12px",
      maxWidth: "860px",
      width: "100%",
      marginTop: "24px",
    }}>
      {data.map((d) => {
        const pct = ((d.population / total) * 100).toFixed(1)

        return (
          <div
            key={d.name}
            style={{
              background: "#0f172a",
              border: "1px solid #1e293b",
              // Left accent stripe — matches bar color
              borderLeft: `3px solid ${d.color}`,
              borderRadius: "10px",
              padding: "14px 16px",
            }}
          >
            {/* Group name */}
            <p style={{ color: "#94a3b8", fontSize: "11px", margin: "0 0 6px", fontWeight: 500 }}>
              {d.name}
            </p>

            {/* Population in billions */}
            <p style={{
              color: d.color,
              fontSize: "20px",
              fontWeight: 800,
              margin: "0 0 2px",
              fontFamily: "'DM Mono', monospace",
            }}>
              {d.population.toFixed(2)}B
            </p>

            {/* % share */}
            <p style={{ color: "#475569", fontSize: "11px", margin: 0 }}>
              {pct}% of total
            </p>
          </div>
        )
      })}
    </div>
  )
}
