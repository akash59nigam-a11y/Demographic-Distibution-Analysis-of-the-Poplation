// src/components/CustomTooltip.jsx
// Recharts custom tooltip — shown when hovering over a bar.
// Displays region/income name, population in billions, and country count.

export default function CustomTooltip({ active, payload }) {
  // Recharts passes `active` as true only when the cursor is over a bar
  if (!active || !payload?.length) return null

  const d = payload[0].payload

  return (
    <div style={{
      background: "#0f172a",
      border: "1px solid #334155",
      borderRadius: "8px",
      padding: "12px 16px",
      boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
    }}>
      {/* Region / income group name */}
      <p style={{ color: "#f1f5f9", fontWeight: 700, margin: "0 0 6px", fontSize: "13px" }}>
        {d.name}
      </p>

      {/* Population figure — colored to match the bar */}
      <p style={{
        color: payload[0].fill,
        margin: "0 0 2px",
        fontSize: "22px",
        fontWeight: 800,
        fontFamily: "'DM Mono', monospace",
      }}>
        {d.population.toFixed(2)}B
      </p>

      {/* Country count */}
      <p style={{ color: "#94a3b8", margin: 0, fontSize: "12px" }}>
        {d.countries} countries
      </p>
    </div>
  )
}
