// src/components/PopulationChart.jsx
// Main page component — holds the view toggle, bar chart, and legend cards.
// All sub-components are imported; data lives in src/data/populationData.js.

import { useState } from "react"
import {
  BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Cell,
} from "recharts"

import { regionData, incomeData } from "../data/populationData"
import CustomTooltip from "./CustomTooltip"
import CustomBar     from "./CustomBar"
import LegendCards   from "./LegendCards"

export default function PopulationChart() {
  // "region" | "income" — controls which dataset is displayed
  const [view, setView] = useState("region")

  const data  = view === "region" ? regionData : incomeData
  const total = data.reduce((sum, d) => sum + d.population, 0)
  const totalCountries = data.reduce((sum, d) => sum + d.countries, 0)

  return (
    <div style={{
      minHeight: "100vh",
      background: "#020817",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      padding: "48px 24px",
      fontFamily: "'Sora', 'Segoe UI', sans-serif",
    }}>

      {/* ── Header ─────────────────────────────────────────── */}
      <div style={{ textAlign: "center", marginBottom: "40px", maxWidth: "640px" }}>
        {/* Dataset attribution badge */}
        <p style={{
          color: "#f97316",
          fontSize: "11px",
          letterSpacing: "0.2em",
          textTransform: "uppercase",
          fontWeight: 600,
          marginBottom: "12px",
          fontFamily: "'DM Mono', monospace",
        }}>
          World Bank · SP.POP.TOTL · 2023
        </p>

        {/* Page title — clamp() keeps it readable on small screens */}
        <h1 style={{
          color: "#f1f5f9",
          fontSize: "clamp(28px, 5vw, 44px)",
          fontWeight: 800,
          lineHeight: 1.1,
          margin: "0 0 14px",
          letterSpacing: "-0.02em",
        }}>
          World Population
          <span style={{ color: "#f97316" }}> Distribution</span>
        </h1>

        {/* Dynamic subtitle updates with toggle */}
        <p style={{ color: "#64748b", fontSize: "15px", lineHeight: 1.6, margin: 0 }}>
          {total.toFixed(2)} billion people across {totalCountries} countries,
          grouped by {view === "region" ? "geographic region" : "income classification"}
        </p>
      </div>

      {/* ── View Toggle ────────────────────────────────────── */}
      <div style={{
        display: "flex",
        background: "#0f172a",
        border: "1px solid #1e293b",
        borderRadius: "10px",
        padding: "4px",
        marginBottom: "36px",
        gap: "4px",
      }}>
        {["region", "income"].map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            aria-pressed={view === v}          /* accessibility */
            style={{
              padding: "8px 22px",
              borderRadius: "7px",
              border: "none",
              cursor: "pointer",
              fontSize: "13px",
              fontWeight: 600,
              letterSpacing: "0.02em",
              transition: "all 0.2s",
              background: view === v ? "#f97316" : "transparent",
              color: view === v ? "#fff" : "#64748b",
              fontFamily: "inherit",
            }}
          >
            By {v.charAt(0).toUpperCase() + v.slice(1)}
          </button>
        ))}
      </div>

      {/* ── Bar Chart ──────────────────────────────────────── */}
      <div style={{
        width: "100%",
        maxWidth: "860px",
        background: "#0f172a",
        border: "1px solid #1e293b",
        borderRadius: "16px",
        padding: "32px 24px 24px",
        boxShadow: "0 24px 80px rgba(0,0,0,0.4)",
        // Horizontal scroll on very small screens so chart is never crushed
        overflowX: "auto",
      }}>
        <ResponsiveContainer width="100%" height={360} minWidth={320}>
          <BarChart
            data={data}
            margin={{ top: 8, right: 12, left: 0, bottom: 60 }}
            barCategoryGap="28%"
          >
            {/* Horizontal grid lines only — vertical ones add clutter */}
            <CartesianGrid vertical={false} stroke="#1e293b" strokeDasharray="0" />

            {/* X axis — angled labels to avoid overlap */}
            <XAxis
              dataKey="name"
              tick={{ fill: "#64748b", fontSize: 11, fontWeight: 500 }}
              axisLine={false}
              tickLine={false}
              angle={-28}
              textAnchor="end"
              interval={0}
              height={70}
            />

            {/* Y axis — values formatted as "XB" */}
            <YAxis
              tickFormatter={(v) => `${v}B`}
              tick={{ fill: "#475569", fontSize: 12, fontFamily: "'DM Mono', monospace" }}
              axisLine={false}
              tickLine={false}
              tickCount={6}
            />

            {/* Custom styled tooltip on hover */}
            <Tooltip
              content={<CustomTooltip />}
              cursor={{ fill: "rgba(255,255,255,0.03)" }}
            />

            {/* Each bar gets its own color via <Cell> */}
            <Bar dataKey="population" shape={<CustomBar />} maxBarSize={72}>
              {data.map((entry, index) => (
                <Cell key={index} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* ── Legend Cards ───────────────────────────────────── */}
      <LegendCards data={data} total={total} />

      {/* ── Footer ─────────────────────────────────────────── */}
      <p style={{ color: "#334155", fontSize: "11px", marginTop: "32px", letterSpacing: "0.05em" }}>
        SOURCE: WORLD BANK · TOTAL POPULATION (SP.POP.TOTL) · 2023 ESTIMATES
      </p>
    </div>
  )
}
