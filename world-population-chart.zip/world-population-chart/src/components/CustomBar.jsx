// src/components/CustomBar.jsx
// Custom Recharts bar shape:
// — Rounded top corners (rx={4} on the main rect)
// — Subtle blurred highlight strip at the top for a "glowing" effect

export default function CustomBar({ x, y, width, height, fill }) {
  return (
    <g>
      {/* Main bar rectangle */}
      <rect x={x} y={y} width={width} height={height} fill={fill} rx={4} />

      {/* Top highlight — small blurred overlay for depth */}
      <rect
        x={x}
        y={y}
        width={width}
        height={Math.min(4, height)} // never taller than the bar itself
        fill={fill}
        opacity={0.6}
        rx={4}
        style={{ filter: "blur(2px)" }}
      />
    </g>
  )
}
