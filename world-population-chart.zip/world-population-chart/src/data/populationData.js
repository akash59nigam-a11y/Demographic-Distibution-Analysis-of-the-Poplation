// src/data/populationData.js
// All chart data in one place — easy to update when new World Bank figures release.
// Source: World Bank SP.POP.TOTL (2023 estimates)

export const regionData = [
  { name: "East Asia & Pacific",    population: 2.36, countries: 37, color: "#f97316" },
  { name: "South Asia",             population: 1.66, countries: 6,  color: "#eab308" },
  { name: "Sub-Saharan Africa",     population: 1.26, countries: 48, color: "#22c55e" },
  { name: "Europe & Central Asia",  population: 0.92, countries: 58, color: "#3b82f6" },
  { name: "Middle East & N. Africa",population: 0.80, countries: 23, color: "#a855f7" },
  { name: "Latin America & Carib.", population: 0.66, countries: 42, color: "#ec4899" },
  { name: "North America",          population: 0.38, countries: 3,  color: "#06b6d4" },
]

export const incomeData = [
  { name: "Lower Middle Income", population: 3.08, countries: 50, color: "#f97316" },
  { name: "Upper Middle Income", population: 2.81, countries: 54, color: "#eab308" },
  { name: "High Income",         population: 1.38, countries: 86, color: "#22c55e" },
  { name: "Low Income",          population: 0.61, countries: 25, color: "#ef4444" },
]
